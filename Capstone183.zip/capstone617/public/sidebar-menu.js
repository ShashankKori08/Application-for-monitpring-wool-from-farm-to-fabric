// Sidebar Menu JavaScript
function createSidebarMenu() {
    return `
    <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
    
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="close-btn" onclick="closeSidebar()">×</button>
            <h2>🐑 Wool Monitor</h2>
            <p>Complete Navigation Menu</p>
        </div>
        
        <div class="menu-section">
            <div class="menu-title">🏠 Main Dashboard</div>
            <a href="../index.html" class="menu-item">
                <i>🏠</i> Home Dashboard
            </a>
            <a href="dashboard.html" class="menu-item">
                <i>📊</i> Analytics Dashboard
            </a>
            <a href="login.html" class="menu-item">
                <i>🔐</i> Login / Register
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">🏭 Farm Management</div>
            <a href="farm-registry.html" class="menu-item">
                <i>🏭</i> Farm Registry
            </a>
            <a href="farm.html" class="menu-item">
                <i>🏡</i> Farm Details
            </a>
            <a href="farm-gallery.html" class="menu-item">
                <i>📸</i> Farm Gallery
            </a>
            <a href="animal-database.html" class="menu-item">
                <i>🐑</i> Animal Database
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">🔗 Supply Chain</div>
            <a href="supply-chain.html" class="menu-item">
                <i>🔗</i> Supply Chain Overview
            </a>
            <a href="supply-chain-tracking.html" class="menu-item">
                <i>📍</i> Supply Chain Tracking
            </a>
            <a href="live-tracking.html" class="menu-item">
                <i>🚛</i> Live GPS Tracking
            </a>

        </div>

        <div class="menu-section">
            <div class="menu-title">🤖 Quality & AI</div>
            <a href="ai-quality.html" class="menu-item">
                <i>🤖</i> AI Quality Assessment
            </a>
            <a href="quality.html" class="menu-item">
                <i>🔍</i> Quality Control
            </a>
            <a href="wool-quality.html" class="menu-item">
                <i>🧶</i> Wool Quality Analysis
            </a>
            <a href="certificates.html" class="menu-item">
                <i>📜</i> Digital Certificates
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">🏛️ Government Portal</div>
            <a href="government-schemes.html" class="menu-item">
                <i>📋</i> Government Schemes
            </a>
            <a href="beneficiaries.html" class="menu-item">
                <i>👥</i> Beneficiaries Portal
            </a>
            <a href="tenders.html" class="menu-item">
                <i>📄</i> Tenders & Procurement
            </a>
            <a href="policies.html" class="menu-item">
                <i>📖</i> Policies & Guidelines
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">💰 Marketplace</div>
            <a href="e-marketplace.html" class="menu-item">
                <i>🛒</i> E-Marketplace
            </a>
            <a href="live-market-prices.html" class="menu-item">
                <i>💰</i> Live Market Prices
            </a>
            <a href="market-prices.html" class="menu-item">
                <i>📈</i> Price Analytics
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">📡 Technology</div>
            <a href="blockchain.html" class="menu-item">
                <i>🔐</i> Blockchain Ledger
            </a>
            <a href="iot-monitoring.html" class="menu-item">
                <i>📡</i> IoT Monitoring
            </a>
            <a href="analytics.html" class="menu-item">
                <i>📊</i> Advanced Analytics
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">🔔 Notifications</div>
            <a href="notifications.html" class="menu-item">
                <i>🔔</i> Notifications Center
            </a>
            <a href="system-status.html" class="menu-item">
                <i>⚡</i> System Status
            </a>
        </div>

        <div class="menu-section">
            <div class="menu-title">⚙️ Settings & Support</div>
            <a href="help-support.html" class="menu-item">
                <i>❓</i> Help & Support
            </a>
        </div>
    </div>
    `;
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('open');
    overlay.classList.toggle('active');
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.remove('open');
    overlay.classList.remove('active');
}

// Initialize sidebar on page load
document.addEventListener('DOMContentLoaded', function() {
    // Add sidebar HTML to body
    document.body.insertAdjacentHTML('afterbegin', createSidebarMenu());
    
    // Add CSS if not already included
    if (!document.querySelector('link[href*="sidebar-menu.css"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'sidebar-menu.css';
        document.head.appendChild(link);
    }
});
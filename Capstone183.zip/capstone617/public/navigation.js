// Navigation system for Wool Monitoring System
function createNavigation() {
    const nav = document.createElement('nav');
    nav.style.cssText = `
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(20px);
        border-bottom: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 1000;
    `;
    
    nav.innerHTML = `
        <div style="max-width: 1400px; margin: 0 auto; padding: 0 20px; display: flex; justify-content: space-between; align-items: center; height: 70px;">
            <a href="../index.html" style="display: flex; align-items: center; gap: 12px; font-size: 1.5em; font-weight: 700; color: white; text-decoration: none; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
                🐑 Wool Monitor
            </a>
            <div style="display: flex; gap: 8px; align-items: center;">
                <a href="dashboard.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Dashboard</a>
                <a href="farm-registry.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Farms</a>
                <a href="supply-chain.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Supply Chain</a>
                <a href="ai-quality.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">AI Quality</a>
                <a href="blockchain.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Blockchain</a>
                <a href="analytics.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Analytics</a>
                <a href="iot-monitoring.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">IoT</a>
                <a href="e-marketplace.html" style="padding: 8px 16px; border-radius: 12px; color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">Marketplace</a>
                <a href="login.html" style="padding: 8px 16px; border-radius: 12px; color: white; text-decoration: none; font-weight: 500; background: linear-gradient(135deg, #667eea, #764ba2); box-shadow: 0 4px 15px rgba(0,0,0,0.2);">Login</a>
            </div>
        </div>
    `;
    
    // Insert navigation at the beginning of body
    if (document.body.firstChild) {
        document.body.insertBefore(nav, document.body.firstChild);
    } else {
        document.body.appendChild(nav);
    }
}

// Auto-initialize navigation if not already present
document.addEventListener('DOMContentLoaded', function() {
    if (!document.querySelector('nav')) {
        createNavigation();
    }
});